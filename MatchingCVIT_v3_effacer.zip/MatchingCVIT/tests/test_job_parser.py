from app.job_parser import parse_job_description

JOB = """
Poste : Développeur Full Stack Java/Angular
Vous maîtrisez Java, Spring Boot et Angular (obligatoire).
La connaissance de Docker et AWS serait un plus.
3 ans d'expérience minimum. Poste confirmé.
"""


def test_required_vs_preferred():
    job = parse_job_description(JOB)
    assert "Java" in job.required_skills
    assert "Spring Boot" in job.required_skills
    assert "Angular" in job.required_skills
    assert "Docker" in job.preferred_skills
    assert "AWS" in job.preferred_skills


def test_years_and_seniority():
    job = parse_job_description(JOB)
    assert job.min_years_experience == 3
    assert job.seniority == "confirmé"


def test_skill_weights_present():
    job = parse_job_description(JOB)
    assert job.skill_weights["Java"] >= 1.0



def test_required_and_preferred_without_colon():
    job = parse_job_description("""
    COMPÉTENCES OBLIGATOIRES
    Java
    Spring Boot
    PostgreSQL

    COMPÉTENCES SOUHAITÉES
    AWS
    Docker
    Kubernetes
    """)
    assert job.required_skills == ["Java", "Spring Boot", "PostgreSQL"]
    assert job.preferred_skills == ["AWS", "Docker", "Kubernetes"]


def test_required_and_preferred_natural_language():
    job = parse_job_description("""
    Le candidat doit maîtriser Java, Spring Boot et PostgreSQL.
    Une expérience avec AWS, Kubernetes et Terraform serait appréciée.
    """)
    assert "Java" in job.required_skills
    assert "Spring Boot" in job.required_skills
    assert "PostgreSQL" in job.required_skills
    assert "AWS" in job.preferred_skills
    assert "Kubernetes" in job.preferred_skills
    assert "Terraform" in job.preferred_skills


def test_english_headings_without_colon():
    job = parse_job_description("""
    REQUIRED SKILLS
    Python
    SQL

    NICE TO HAVE
    Azure
    Docker
    """)
    assert "Python" in job.required_skills
    assert "SQL" in job.required_skills
    assert "Azure" in job.preferred_skills
    assert "Docker" in job.preferred_skills
