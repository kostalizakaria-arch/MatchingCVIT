from app.experience_extractor import extract_experience_blocks, chronology_alerts

OVERLAPPING_CV = """
EXPERIENCE 2020-2023
Développeur chez Entreprise A.

EXPERIENCE 2022-2025
Développeur chez Entreprise B.
"""

CLEAN_CV = """
EXPERIENCE 2018-2020
Développeur chez Entreprise A.

EXPERIENCE 2020-2023
Développeur chez Entreprise B.
"""


def test_detects_overlap():
    blocks = extract_experience_blocks(OVERLAPPING_CV)
    alerts = chronology_alerts(blocks)
    assert len(alerts) == 1
    assert "Chevauchement" in alerts[0]


def test_no_false_positive_on_consecutive_periods():
    blocks = extract_experience_blocks(CLEAN_CV)
    alerts = chronology_alerts(blocks)
    assert alerts == []
