from app.demo import run_demo
from app.qa import ask_about_skill


def test_qa_answers_yes_for_confirmed_skill():
    results = {r[0]: r[1] for r in run_demo()}
    java = next(s for s in results["Ahmed"] if s.skill == "Java")
    answer = ask_about_skill(java)
    assert answer.startswith("Oui")
    assert "confiance" in answer.lower()


def test_qa_flags_declared_but_not_demonstrated():
    results = {r[0]: r[1] for r in run_demo()}
    java = next(s for s in results["Sara"] if s.skill == "Java")
    answer = ask_about_skill(java)
    assert "Oui" != answer.split(" —")[0]
