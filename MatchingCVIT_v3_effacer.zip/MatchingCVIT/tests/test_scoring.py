from app.demo import run_demo


def test_demo_has_two_candidates():
    results = run_demo()
    assert len(results) == 2


def test_ahmed_beats_sara():
    results = {r[0]: r[2] for r in run_demo()}
    assert results["Ahmed"][0] > results["Sara"][0]


def test_ahmed_java_confirmed():
    results = {r[0]: r[1] for r in run_demo()}
    java = next(s for s in results["Ahmed"] if s.skill == "Java")
    assert java.verdict == "CONFIRMED"
    assert java.duration_years > 0


def test_sara_java_only_declared_not_confirmed():
    results = {r[0]: r[1] for r in run_demo()}
    java = next(s for s in results["Sara"] if s.skill == "Java")
    # Java est dans les compétences de Sara mais jamais mentionné dans une expérience/projet
    assert java.declared is True
    assert java.verdict in ("VERIFY", "NOT_DEMONSTRATED")
